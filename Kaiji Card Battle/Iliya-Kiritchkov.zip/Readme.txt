=================================
!@#$%^& Kaiji Card Battle &^%$#@!

@@@AUTHOR@@@ --- ILIYA KIRITCHKOV
@@@@DATE@@@@ --- October 3, 2018
=================================

Double click on Kaiji Card Battle.jar to play the game.

Please DO NOT leave the game while waiting for
an opponent as this will put a big boo-boo on the server.

If anything breaks, please exit the game and reconnect to the server.